package com.tfg.tfgbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TfgBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TfgBackendApplication.class, args);
	}

}
